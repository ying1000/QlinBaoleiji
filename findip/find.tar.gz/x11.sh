#!/bin/bash

IP=`./findip`

echo $IP
